    
        <div class="row" style="background:url(images/immg2.jpg); color:white;min-height:100vh;">
            <div class="col-lg-12">
                <h1 class="page-header" align="center"><font color="white">STUDENT FEEDBACK SYSTEM</font> </h1>
                <hr>
                <P style="font-size:20px"> The Student Feedback System is used to manages feedback provided by students.
Student Feedback System allows students to select particular subject and respective
teacher to give feedback about teacher and subject. A Student Feedback System is
an feedback generation system which gives proper feedback to teacher provides the
proper feedback to the teachers about their teaching quality on basis of rating very
poor, poor, average, good, very good. In the existing system students requires
giving feedback manually. In existing system report generation by analyzing all
feedback form is very time consuming. By online feedback system report
generation is consumes very less time. In online feedback system student gives
feedback for teacher of particular subject for particular period of time may be at
month end. Feedback is send to HOD of particular department as well as all
departments’ feedback to principal. HOD has rights to whether feedback shows to
respected teacher or not. After analyzing report HOD or principle conducts the
meetings for staff by send mail to them.
<br>
<br>
The Student Feedback System is a management
information system for education establishments to
manage student data. Student Feedback Systems
provide capabilities for selecting particular subject for
feedback and generate the report automatically, build
student details, student-related data needs in a college.
An Student Feedback System is an automatic feedback
generation system that provides the proper feedback to
the teachers as per the categories like always, poor,
usually, very often, sometimes. In the existing system
students can give feedback about the lecturers by
doing manually. By this process student can give
feedback in online system without wasting his time in
writing. After giving feedback by every student papers
are collected by the faculty and calculated the overall
grade for each subject and each lecturer.
</P> 
            </div>
        <!-- /.row -->

     